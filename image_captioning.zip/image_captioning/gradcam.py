"""
gradcam.py
----------
Grad-CAM explainability for the ResNet50 encoder used in this captioning
model.

Standard Grad-CAM is defined for a single scalar output (e.g. a class
logit). For captioning there's no single "class", so we compute Grad-CAM
per generated word: we backprop the log-probability of the chosen word at
each decoding step through the encoder's last conv layer (layer4), producing
a heatmap of "which image regions this word's decision leaned on."

This is exactly the "failure case analysis" tool referenced in the resume
bullet: run it on captions the model got wrong and visually inspect whether
attention is on the right object, the wrong object, or the background.

Usage:
    python gradcam.py --checkpoint checkpoints/best_model.pt \
                       --image path/to/image.jpg \
                       --out outputs/gradcam.png
"""

import os
import argparse

import numpy as np
import torch
import torch.nn.functional as F
import cv2
import matplotlib.pyplot as plt
from PIL import Image

from vocab import Vocabulary
from dataset import get_transforms, IMAGENET_MEAN, IMAGENET_STD
from model import ImageCaptioningModel


class GradCAM:
    """
    Hooks the last conv block of ResNet50 (layer4, index 7 in the
    Sequential built in model.ResNetEncoder) to capture activations and
    gradients, then computes the Grad-CAM weighted activation map.
    """

    def __init__(self, model: ImageCaptioningModel):
        self.model = model
        self.activations = None
        self.gradients = None

        target_layer = self.model.encoder.resnet[7]  # layer4
        target_layer.register_forward_hook(self._save_activation)
        target_layer.register_full_backward_hook(self._save_gradient)

    def _save_activation(self, module, inp, out):
        self.activations = out.detach()

    def _save_gradient(self, module, grad_in, grad_out):
        self.gradients = grad_out[0].detach()

    def compute(self, images, vocab, max_len=30, device="cpu"):
        """
        Runs greedy generation while, at each decoding step, backpropagating
        the chosen word's log-probability to produce a Grad-CAM heatmap for
        that word.

        Returns:
            words: list[str] generated words (excluding <start>/<end>)
            heatmaps: list[np.ndarray], each (H, W) in [0, 1], one per word
        """
        self.model.eval()
        images = images.to(device)

        start_idx = vocab.word2idx["<start>"]
        end_idx = vocab.word2idx["<end>"]
        generated = torch.tensor([[start_idx]], dtype=torch.long, device=device)

        words = []
        heatmaps = []

        for _ in range(max_len - 1):
            self.model.zero_grad()
            memory = self.model.encoder(images)  # triggers forward hook -> self.activations
            logits = self.model.decoder(memory, generated)
            log_probs = F.log_softmax(logits[:, -1, :], dim=-1)  # (1, vocab)

            next_token = log_probs.argmax(dim=-1)
            chosen_log_prob = log_probs[0, next_token]

            # backprop this word's log-prob to get gradients at layer4
            chosen_log_prob.backward()

            heatmap = self._make_heatmap()
            heatmaps.append(heatmap)

            word = vocab.idx2word.get(int(next_token.item()), "<unk>")
            if word == "<end>" or next_token.item() == end_idx:
                break
            words.append(word)

            generated = torch.cat([generated, next_token.unsqueeze(0)], dim=1)

        return words, heatmaps

    def _make_heatmap(self):
        # gradients/activations: (1, C, H, W)
        weights = self.gradients.mean(dim=(2, 3), keepdim=True)  # (1, C, 1, 1) - global avg pool of grads
        cam = (weights * self.activations).sum(dim=1, keepdim=True)  # (1, 1, H, W)
        cam = F.relu(cam)
        cam = cam.squeeze().cpu().numpy()
        if cam.max() > 0:
            cam = cam / cam.max()
        return cam


def overlay_heatmap_on_image(pil_image, heatmap, alpha=0.45):
    """heatmap: (H, W) in [0,1] -> resized + colorized + blended onto the original image."""
    img = np.array(pil_image.convert("RGB"))
    heatmap_resized = cv2.resize(heatmap, (img.shape[1], img.shape[0]))
    heatmap_uint8 = np.uint8(255 * heatmap_resized)
    colored = cv2.applyColorMap(heatmap_uint8, cv2.COLORMAP_JET)
    colored = cv2.cvtColor(colored, cv2.COLOR_BGR2RGB)
    overlay = np.uint8(img * (1 - alpha) + colored * alpha)
    return overlay


def run(checkpoint_path, image_path, out_path, vocab_path=None):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    vocab_path = vocab_path or os.path.join(os.path.dirname(checkpoint_path), "vocab.json")
    vocab = Vocabulary.load(vocab_path)

    ckpt = torch.load(checkpoint_path, map_location=device)
    model = ImageCaptioningModel(
        vocab_size=ckpt["vocab_size"],
        d_model=ckpt["d_model"],
        nhead=ckpt["nhead"],
        num_layers=ckpt["num_layers"],
        max_len=ckpt["max_len"],
        pad_idx=ckpt["pad_idx"],
    ).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    gradcam = GradCAM(model)

    pil_image = Image.open(image_path).convert("RGB")
    transform = get_transforms(train=False)
    image_tensor = transform(pil_image).unsqueeze(0)

    words, heatmaps = gradcam.compute(image_tensor, vocab, max_len=ckpt["max_len"], device=str(device))

    print("Generated caption:", " ".join(words))

    # plot: original image + one heatmap panel per word (up to 8 words shown)
    n_show = min(len(words), 8)
    fig, axes = plt.subplots(1, n_show + 1, figsize=(3 * (n_show + 1), 3))

    axes[0].imshow(pil_image)
    axes[0].set_title("Original")
    axes[0].axis("off")

    for i in range(n_show):
        overlay = overlay_heatmap_on_image(pil_image, heatmaps[i])
        axes[i + 1].imshow(overlay)
        axes[i + 1].set_title(words[i])
        axes[i + 1].axis("off")

    plt.tight_layout()
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    print(f"Saved Grad-CAM visualization to {out_path}")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--image", type=str, required=True)
    p.add_argument("--out", type=str, default="outputs/gradcam.png")
    p.add_argument("--vocab_path", type=str, default=None)
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run(args.checkpoint, args.image, args.out, args.vocab_path)
