# Image Captioning with ResNet50 + Transformer Decoder (+ Grad-CAM Explainability)

A complete, minimal, end-to-end image captioning pipeline:

- **Encoder**: Pretrained ResNet50 (ImageNet weights) → spatial feature map
- **Decoder**: Transformer decoder (multi-head self-attention + cross-attention over image features)
- **Explainability**: Grad-CAM heatmaps showing which image regions influenced each generated word
- **Metric**: BLEU-4 score on a held-out test split

## 1. Project structure

```
image_captioning/
├── data/                    # put dataset here (see below)
├── checkpoints/             # saved model weights go here
├── outputs/                 # generated captions / Grad-CAM images go here
├── vocab.py                 # tokenizer + vocabulary builder
├── dataset.py               # PyTorch Dataset + collate_fn (padding)
├── model.py                 # ResNet50 encoder + Transformer decoder
├── train.py                 # training loop
├── evaluate.py               # BLEU-4 evaluation on test set
├── generate_caption.py       # run inference on a single image
├── gradcam.py                # Grad-CAM explainability
└── requirements.txt
```

## 2. Dataset format expected

This project expects the **Flickr8k** layout (also works for Flickr30k with path tweaks):

```
data/
├── Images/
│   ├── 1000268201_693b08cb0e.jpg
│   ├── ...
└── captions.txt      # format: image,caption   (one caption per line, header row ok)
```

`captions.txt` example:
```
image,caption
1000268201_693b08cb0e.jpg,A child in a pink dress is climbing up a set of stairs.
1000268201_693b08cb0e.jpg,A little girl in a pink dress going into a wooden cabin.
```

Download Flickr8k from Kaggle: https://www.kaggle.com/datasets/adityajn105/flickr8k
Unzip so that `Images/` and `captions.txt` sit under `data/`.

## 3. Install

```bash
pip install -r requirements.txt
```

## 4. Train

```bash
python train.py --data_dir data --epochs 15 --batch_size 32
```

This will:
- build a vocabulary from the training captions (with `<pad> <start> <end> <unk>`)
- freeze most of ResNet50, fine-tune the last block
- train the Transformer decoder with teacher forcing + padding masks
- save the best checkpoint to `checkpoints/best_model.pt`

## 5. Evaluate (BLEU-4)

```bash
python evaluate.py --checkpoint checkpoints/best_model.pt --data_dir data
```

## 6. Generate a caption for a new image

```bash
python generate_caption.py --checkpoint checkpoints/best_model.pt --image path/to/image.jpg
```

## 7. Grad-CAM explainability

```bash
python gradcam.py --checkpoint checkpoints/best_model.pt --image path/to/image.jpg --out outputs/gradcam.png
```

This produces a heatmap overlay showing which image regions the CNN encoder relied on
most, plus (optionally) per-word attention-based heatmaps from the Transformer decoder's
cross-attention, so you can inspect *why* a caption went wrong on failure cases.

## Notes on the honesty of this implementation

- BLEU-4 scores on Flickr8k for a model this size typically land around **0.15–0.25** with a
  few epochs of training on a single GPU/Colab — matching what you'd realistically report.
- "Training time reduction" only means something relative to a stated baseline
  (e.g., freezing ResNet50 vs fine-tuning the whole backbone). This code freezes most of
  ResNet50 by default — you can toggle that in `model.py` (`freeze_backbone`) and time
  both runs yourself to get a real, defensible number for your resume.
