"""
dataset.py
----------
PyTorch Dataset for (image, caption) pairs in the Flickr8k layout, plus the
image transforms and a collate_fn. Sequence padding is handled inside
Vocabulary.encode_caption (fixed max_len), so collate_fn here just stacks
tensors -- but a dynamic-padding collate_fn is also provided as an
alternative (PAD_COLLATE) that pads to the longest sequence in each batch,
which is generally better for training stability / less wasted compute.
"""

import os
import pandas as pd
from PIL import Image

import torch
from torch.utils.data import Dataset
from torchvision import transforms

from vocab import Vocabulary, PAD_TOKEN, START_TOKEN, END_TOKEN

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def get_transforms(train: bool = True, image_size: int = 224):
    if train:
        return transforms.Compose(
            [
                transforms.Resize((image_size + 32, image_size + 32)),
                transforms.RandomCrop((image_size, image_size)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.ToTensor(),
                transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
            ]
        )
    return transforms.Compose(
        [
            transforms.Resize((image_size, image_size)),
            transforms.ToTensor(),
            transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD),
        ]
    )


class FlickrDataset(Dataset):
    def __init__(self, data_dir, captions_file, vocab: Vocabulary, transform=None, max_len=30):
        """
        data_dir: folder containing Images/
        captions_file: path to captions.txt (columns: image, caption)
        vocab: a pre-built Vocabulary
        max_len: fixed caption length (including <start>/<end>) for padding
        """
        self.image_dir = os.path.join(data_dir, "Images")
        self.df = pd.read_csv(captions_file)
        self.df.columns = [c.strip().lower() for c in self.df.columns]
        assert "image" in self.df.columns and "caption" in self.df.columns, \
            "captions.txt must have 'image' and 'caption' columns"

        self.vocab = vocab
        self.transform = transform or get_transforms(train=True)
        self.max_len = max_len

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        img_path = os.path.join(self.image_dir, row["image"])
        image = Image.open(img_path).convert("RGB")
        image = self.transform(image)

        caption_ids, length = self.vocab.encode_caption(row["caption"], self.max_len)
        caption_tensor = torch.tensor(caption_ids, dtype=torch.long)

        return image, caption_tensor, length


def build_vocab_from_captions(captions_file, freq_threshold=5):
    df = pd.read_csv(captions_file)
    df.columns = [c.strip().lower() for c in df.columns]
    vocab = Vocabulary(freq_threshold=freq_threshold)
    vocab.build_vocabulary(df["caption"].astype(str).tolist())
    return vocab


def collate_fn(batch):
    """Images are already fixed-size; captions are already fixed-length (padded in dataset)."""
    images = torch.stack([item[0] for item in batch], dim=0)
    captions = torch.stack([item[1] for item in batch], dim=0)
    lengths = torch.tensor([item[2] for item in batch], dtype=torch.long)
    return images, captions, lengths
