"""
vocab.py
--------
Simple whitespace tokenizer + vocabulary builder for image captions.

This is the "NLP preprocessing pipeline" piece: it lowercases, strips
punctuation, tokenizes, builds a word->index mapping with special tokens,
and provides encode/decode helpers used by dataset.py.
"""

import re
import json
from collections import Counter

PAD_TOKEN = "<pad>"
START_TOKEN = "<start>"
END_TOKEN = "<end>"
UNK_TOKEN = "<unk>"


def tokenize(text: str):
    """Lowercase, remove punctuation (keep letters/numbers/spaces), split on whitespace."""
    text = text.lower().strip()
    text = re.sub(r"[^a-z0-9\s]", "", text)
    tokens = text.split()
    return tokens


class Vocabulary:
    def __init__(self, freq_threshold: int = 5):
        """
        freq_threshold: words appearing fewer than this many times are mapped to <unk>.
        """
        self.freq_threshold = freq_threshold
        self.word2idx = {}
        self.idx2word = {}

    def __len__(self):
        return len(self.word2idx)

    def build_vocabulary(self, sentence_list):
        """Build vocab from a list of raw caption strings."""
        counter = Counter()
        for sentence in sentence_list:
            counter.update(tokenize(sentence))

        # special tokens first, fixed indices
        specials = [PAD_TOKEN, START_TOKEN, END_TOKEN, UNK_TOKEN]
        idx = 0
        for tok in specials:
            self.word2idx[tok] = idx
            self.idx2word[idx] = tok
            idx += 1

        for word, freq in counter.items():
            if freq >= self.freq_threshold and word not in self.word2idx:
                self.word2idx[word] = idx
                self.idx2word[idx] = word
                idx += 1

    def numericalize(self, text: str):
        """Convert a raw caption string into a list of token indices (no start/end added)."""
        tokens = tokenize(text)
        return [
            self.word2idx.get(tok, self.word2idx[UNK_TOKEN]) for tok in tokens
        ]

    def encode_caption(self, text: str, max_len: int):
        """
        Full pipeline used for training targets:
        <start> + tokens + <end>, then pad/truncate to max_len.
        Returns (ids: List[int], length: int) where length excludes padding.
        """
        ids = [self.word2idx[START_TOKEN]] + self.numericalize(text) + [self.word2idx[END_TOKEN]]
        length = min(len(ids), max_len)
        if len(ids) < max_len:
            ids = ids + [self.word2idx[PAD_TOKEN]] * (max_len - len(ids))
        else:
            ids = ids[:max_len]
            ids[-1] = self.word2idx[END_TOKEN]  # ensure sequence still ends properly
        return ids, length

    def decode(self, ids, skip_special=True):
        words = []
        for i in ids:
            word = self.idx2word.get(int(i), UNK_TOKEN)
            if skip_special and word in (PAD_TOKEN, START_TOKEN, END_TOKEN):
                if word == END_TOKEN:
                    break
                continue
            words.append(word)
        return " ".join(words)

    def save(self, path):
        with open(path, "w") as f:
            json.dump(
                {"word2idx": self.word2idx, "freq_threshold": self.freq_threshold}, f
            )

    @classmethod
    def load(cls, path):
        with open(path, "r") as f:
            data = json.load(f)
        vocab = cls(freq_threshold=data["freq_threshold"])
        vocab.word2idx = data["word2idx"]
        vocab.idx2word = {int(v): k for k, v in vocab.word2idx.items()}
        return vocab
