"""
train.py
--------
Trains the ResNet50 encoder + Transformer decoder captioning model with
teacher forcing. Saves the vocabulary and the best checkpoint (by
validation loss) to checkpoints/.

Usage:
    python train.py --data_dir data --epochs 15 --batch_size 32
"""

import os
import argparse
import time

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from tqdm import tqdm

from dataset import FlickrDataset, build_vocab_from_captions, get_transforms, collate_fn
from model import ImageCaptioningModel


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", type=str, default="data")
    p.add_argument("--captions_file", type=str, default=None,
                    help="defaults to <data_dir>/captions.txt")
    p.add_argument("--epochs", type=int, default=15)
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--max_len", type=int, default=30)
    p.add_argument("--freq_threshold", type=int, default=5)
    p.add_argument("--d_model", type=int, default=512)
    p.add_argument("--nhead", type=int, default=8)
    p.add_argument("--num_layers", type=int, default=4)
    p.add_argument("--freeze_backbone", action="store_true", default=True)
    p.add_argument("--no_freeze_backbone", dest="freeze_backbone", action="store_false")
    p.add_argument("--val_split", type=float, default=0.1)
    p.add_argument("--checkpoint_dir", type=str, default="checkpoints")
    p.add_argument("--num_workers", type=int, default=2)
    return p.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.checkpoint_dir, exist_ok=True)

    captions_file = args.captions_file or os.path.join(args.data_dir, "captions.txt")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # ---- Vocabulary ----
    print("Building vocabulary...")
    vocab = build_vocab_from_captions(captions_file, freq_threshold=args.freq_threshold)
    vocab.save(os.path.join(args.checkpoint_dir, "vocab.json"))
    print(f"Vocabulary size: {len(vocab)}")

    # ---- Datasets ----
    full_dataset = FlickrDataset(
        args.data_dir, captions_file, vocab,
        transform=get_transforms(train=True), max_len=args.max_len,
    )
    val_size = int(len(full_dataset) * args.val_split)
    train_size = len(full_dataset) - val_size
    train_dataset, val_dataset = random_split(full_dataset, [train_size, val_size])
    # validation should use eval-time transforms (no augmentation)
    val_dataset.dataset.transform = get_transforms(train=False)

    train_loader = DataLoader(
        train_dataset, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, collate_fn=collate_fn,
    )
    val_loader = DataLoader(
        val_dataset, batch_size=args.batch_size, shuffle=False,
        num_workers=args.num_workers, collate_fn=collate_fn,
    )
    print(f"Train samples: {train_size} | Val samples: {val_size}")

    # ---- Model ----
    pad_idx = vocab.word2idx["<pad>"]
    model = ImageCaptioningModel(
        vocab_size=len(vocab),
        d_model=args.d_model,
        nhead=args.nhead,
        num_layers=args.num_layers,
        max_len=args.max_len,
        pad_idx=pad_idx,
        freeze_backbone=args.freeze_backbone,
    ).to(device)

    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Trainable params: {trainable_params:,} / {total_params:,}")

    criterion = nn.CrossEntropyLoss(ignore_index=pad_idx)
    optimizer = torch.optim.Adam(
        filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr
    )

    best_val_loss = float("inf")
    start_time = time.time()

    for epoch in range(1, args.epochs + 1):
        # ---- Train ----
        model.train()
        train_loss = 0.0
        loop = tqdm(train_loader, desc=f"Epoch {epoch}/{args.epochs} [train]")
        for images, captions, lengths in loop:
            images, captions = images.to(device), captions.to(device)

            decoder_input = captions[:, :-1]
            targets = captions[:, 1:]

            logits = model(images, decoder_input)
            loss = criterion(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))

            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

            train_loss += loss.item()
            loop.set_postfix(loss=loss.item())

        avg_train_loss = train_loss / len(train_loader)

        # ---- Validate ----
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for images, captions, lengths in val_loader:
                images, captions = images.to(device), captions.to(device)
                decoder_input = captions[:, :-1]
                targets = captions[:, 1:]
                logits = model(images, decoder_input)
                loss = criterion(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
                val_loss += loss.item()
        avg_val_loss = val_loss / max(len(val_loader), 1)

        elapsed = time.time() - start_time
        print(
            f"Epoch {epoch}: train_loss={avg_train_loss:.4f} "
            f"val_loss={avg_val_loss:.4f} elapsed={elapsed/60:.1f}min"
        )

        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            ckpt_path = os.path.join(args.checkpoint_dir, "best_model.pt")
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "vocab_size": len(vocab),
                    "d_model": args.d_model,
                    "nhead": args.nhead,
                    "num_layers": args.num_layers,
                    "max_len": args.max_len,
                    "pad_idx": pad_idx,
                    "epoch": epoch,
                    "val_loss": avg_val_loss,
                },
                ckpt_path,
            )
            print(f"  -> Saved new best checkpoint (val_loss={avg_val_loss:.4f}) to {ckpt_path}")

    total_time = time.time() - start_time
    print(f"Training complete in {total_time/60:.1f} minutes. Best val_loss={best_val_loss:.4f}")


if __name__ == "__main__":
    main()
