"""
generate_caption.py
--------------------
Run the trained model on a single image and print the generated caption.

Usage:
    python generate_caption.py --checkpoint checkpoints/best_model.pt --image path/to/image.jpg
"""

import os
import argparse

import torch
from PIL import Image

from vocab import Vocabulary
from dataset import get_transforms
from model import ImageCaptioningModel


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--image", type=str, required=True)
    p.add_argument("--vocab_path", type=str, default=None)
    return p.parse_args()


def load_model_and_vocab(checkpoint_path, vocab_path=None, device="cpu"):
    vocab_path = vocab_path or os.path.join(os.path.dirname(checkpoint_path), "vocab.json")
    vocab = Vocabulary.load(vocab_path)

    ckpt = torch.load(checkpoint_path, map_location=device)
    model = ImageCaptioningModel(
        vocab_size=ckpt["vocab_size"],
        d_model=ckpt["d_model"],
        nhead=ckpt["nhead"],
        num_layers=ckpt["num_layers"],
        max_len=ckpt["max_len"],
        pad_idx=ckpt["pad_idx"],
    ).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    return model, vocab, ckpt


def caption_image(model, vocab, image_path, max_len, device="cpu"):
    transform = get_transforms(train=False)
    image = Image.open(image_path).convert("RGB")
    image_tensor = transform(image).unsqueeze(0)
    generated_ids = model.generate(image_tensor, vocab, max_len=max_len, device=device)
    return vocab.decode(generated_ids)


def main():
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model, vocab, ckpt = load_model_and_vocab(args.checkpoint, args.vocab_path, device=str(device))
    caption = caption_image(model, vocab, args.image, ckpt["max_len"], device=str(device))

    print(f"\nImage: {args.image}")
    print(f"Generated caption: {caption}")


if __name__ == "__main__":
    main()
