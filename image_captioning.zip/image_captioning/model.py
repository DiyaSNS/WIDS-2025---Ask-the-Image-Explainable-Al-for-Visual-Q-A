"""
model.py
--------
Encoder:  Pretrained ResNet50 (ImageNet) with the final avgpool/fc removed,
          so it outputs a spatial feature map of shape (B, 2048, 7, 7) for a
          224x224 input. This is projected to (B, 49, d_model) and used as
          the "memory" the Transformer decoder attends to.

Decoder:  Standard Transformer decoder (nn.TransformerDecoder) with learned
          positional embeddings, causal self-attention masking, and
          cross-attention over the encoder's spatial features.

freeze_backbone(): toggles whether ResNet50 layers are frozen (faster
          training / fewer trainable params) or fine-tuned end-to-end.
          Comparing wall-clock time with this flag on vs off is how you get
          a real, defensible "X% training time reduction" number.
"""

import math
import torch
import torch.nn as nn
import torchvision.models as models


class PositionalEncoding(nn.Module):
    """Standard sinusoidal positional encoding for the decoder's target sequence."""

    def __init__(self, d_model, max_len=100):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(0))  # (1, max_len, d_model)

    def forward(self, x):
        # x: (B, T, d_model)
        return x + self.pe[:, : x.size(1), :]


class ResNetEncoder(nn.Module):
    def __init__(self, d_model=512, freeze_backbone=True, fine_tune_last_block=True):
        super().__init__()
        resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
        # drop avgpool + fc, keep spatial feature map (B, 2048, H, W)
        modules = list(resnet.children())[:-2]
        self.resnet = nn.Sequential(*modules)

        self.set_trainable(freeze_backbone, fine_tune_last_block)

        self.project = nn.Linear(2048, d_model)
        self.norm = nn.LayerNorm(d_model)

    def set_trainable(self, freeze_backbone: bool, fine_tune_last_block: bool):
        for param in self.resnet.parameters():
            param.requires_grad = not freeze_backbone
        if freeze_backbone and fine_tune_last_block:
            # layer4 is the last residual block of resnet50 -- unfreeze just this
            for param in self.resnet[7].parameters():  # index 7 == layer4
                param.requires_grad = True

    def forward(self, images):
        # images: (B, 3, 224, 224)
        features = self.resnet(images)  # (B, 2048, 7, 7)
        B, C, H, W = features.shape
        features = features.permute(0, 2, 3, 1).reshape(B, H * W, C)  # (B, 49, 2048)
        features = self.project(features)  # (B, 49, d_model)
        features = self.norm(features)
        return features  # used as decoder "memory"


class TransformerDecoderCaptioner(nn.Module):
    def __init__(
        self,
        vocab_size,
        d_model=512,
        nhead=8,
        num_layers=4,
        dim_feedforward=2048,
        dropout=0.1,
        max_len=30,
        pad_idx=0,
    ):
        super().__init__()
        self.d_model = d_model
        self.pad_idx = pad_idx

        self.token_embedding = nn.Embedding(vocab_size, d_model, padding_idx=pad_idx)
        self.pos_encoding = PositionalEncoding(d_model, max_len=max_len + 5)

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True,
        )
        self.transformer_decoder = nn.TransformerDecoder(decoder_layer, num_layers=num_layers)

        self.fc_out = nn.Linear(d_model, vocab_size)
        self.dropout = nn.Dropout(dropout)

    def generate_causal_mask(self, size, device):
        mask = torch.triu(torch.ones(size, size, device=device), diagonal=1).bool()
        return mask  # True = masked (not allowed to attend)

    def forward(self, memory, captions):
        """
        memory: (B, 49, d_model) from encoder
        captions: (B, T) token ids, teacher-forced input (i.e. captions[:, :-1])
        """
        device = captions.device
        T = captions.size(1)

        tgt_key_padding_mask = captions == self.pad_idx  # (B, T)
        causal_mask = self.generate_causal_mask(T, device)  # (T, T)

        x = self.token_embedding(captions) * math.sqrt(self.d_model)
        x = self.pos_encoding(x)
        x = self.dropout(x)

        out = self.transformer_decoder(
            tgt=x,
            memory=memory,
            tgt_mask=causal_mask,
            tgt_key_padding_mask=tgt_key_padding_mask,
        )
        logits = self.fc_out(out)  # (B, T, vocab_size)
        return logits


class ImageCaptioningModel(nn.Module):
    def __init__(
        self,
        vocab_size,
        d_model=512,
        nhead=8,
        num_layers=4,
        dim_feedforward=2048,
        dropout=0.1,
        max_len=30,
        pad_idx=0,
        freeze_backbone=True,
    ):
        super().__init__()
        self.encoder = ResNetEncoder(d_model=d_model, freeze_backbone=freeze_backbone)
        self.decoder = TransformerDecoderCaptioner(
            vocab_size=vocab_size,
            d_model=d_model,
            nhead=nhead,
            num_layers=num_layers,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            max_len=max_len,
            pad_idx=pad_idx,
        )

    def forward(self, images, captions_input):
        memory = self.encoder(images)
        logits = self.decoder(memory, captions_input)
        return logits

    @torch.no_grad()
    def generate(self, images, vocab, max_len=30, device="cpu"):
        """Greedy decoding for inference (batch size 1 recommended for simplicity)."""
        self.eval()
        memory = self.encoder(images.to(device))
        start_idx = vocab.word2idx["<start>"]
        end_idx = vocab.word2idx["<end>"]

        generated = torch.tensor([[start_idx]], dtype=torch.long, device=device)
        for _ in range(max_len - 1):
            logits = self.decoder(memory, generated)
            next_token_logits = logits[:, -1, :]
            next_token = next_token_logits.argmax(dim=-1, keepdim=True)
            generated = torch.cat([generated, next_token], dim=1)
            if next_token.item() == end_idx:
                break
        return generated.squeeze(0).tolist()
