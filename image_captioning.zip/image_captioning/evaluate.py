"""
evaluate.py
-----------
Computes corpus-level BLEU-4 on a held-out set of images, comparing the
model's greedily-generated caption against ALL reference captions available
for that image (standard multi-reference BLEU evaluation).

Usage:
    python evaluate.py --checkpoint checkpoints/best_model.pt --data_dir data
"""

import os
import argparse
from collections import defaultdict

import torch
import pandas as pd
from PIL import Image
from tqdm import tqdm
from nltk.translate.bleu_score import corpus_bleu, SmoothingFunction

from vocab import Vocabulary, tokenize
from dataset import get_transforms
from model import ImageCaptioningModel


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", type=str, required=True)
    p.add_argument("--data_dir", type=str, default="data")
    p.add_argument("--captions_file", type=str, default=None)
    p.add_argument("--vocab_path", type=str, default=None)
    p.add_argument("--num_images", type=int, default=200,
                    help="evaluate on a subset for speed; set -1 for all unique images")
    return p.parse_args()


def main():
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    captions_file = args.captions_file or os.path.join(args.data_dir, "captions.txt")
    vocab_path = args.vocab_path or os.path.join(os.path.dirname(args.checkpoint), "vocab.json")

    vocab = Vocabulary.load(vocab_path)

    ckpt = torch.load(args.checkpoint, map_location=device)
    model = ImageCaptioningModel(
        vocab_size=ckpt["vocab_size"],
        d_model=ckpt["d_model"],
        nhead=ckpt["nhead"],
        num_layers=ckpt["num_layers"],
        max_len=ckpt["max_len"],
        pad_idx=ckpt["pad_idx"],
    ).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    # group references by image
    df = pd.read_csv(captions_file)
    df.columns = [c.strip().lower() for c in df.columns]
    refs_by_image = defaultdict(list)
    for _, row in df.iterrows():
        refs_by_image[row["image"]].append(tokenize(str(row["caption"])))

    image_names = list(refs_by_image.keys())
    if args.num_images > 0:
        image_names = image_names[: args.num_images]

    transform = get_transforms(train=False)
    image_dir = os.path.join(args.data_dir, "Images")

    references = []
    hypotheses = []

    for img_name in tqdm(image_names, desc="Evaluating"):
        img_path = os.path.join(image_dir, img_name)
        if not os.path.exists(img_path):
            continue
        image = Image.open(img_path).convert("RGB")
        image_tensor = transform(image).unsqueeze(0)

        generated_ids = model.generate(image_tensor, vocab, max_len=ckpt["max_len"], device=str(device))
        hypothesis_text = vocab.decode(generated_ids)
        hypothesis_tokens = hypothesis_text.split()

        references.append(refs_by_image[img_name])   # list of reference token-lists
        hypotheses.append(hypothesis_tokens)

    smoothie = SmoothingFunction().method4
    bleu4 = corpus_bleu(references, hypotheses, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=smoothie)
    bleu1 = corpus_bleu(references, hypotheses, weights=(1.0, 0, 0, 0), smoothing_function=smoothie)

    print(f"\nEvaluated on {len(hypotheses)} images")
    print(f"BLEU-1: {bleu1:.4f}")
    print(f"BLEU-4: {bleu4:.4f}")


if __name__ == "__main__":
    main()
